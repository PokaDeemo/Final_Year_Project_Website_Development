package assgn2;

import java.io.Serializable;

public class Address implements Serializable {
	private int streetNum;
	private String streetName;
	private String suburb;
	private int postcode;
	
	public Address(int streetNum, String streetName, String suburb, int postcode) {
		this.streetNum = streetNum;
		this.streetName = streetName;
		this.suburb = suburb;
		this.postcode = postcode;
	}

	public int getStreetNum() {
		return streetNum;
	}

	public void setStreetNum(int streetNum) {
		this.streetNum = streetNum;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getSuburb() {
		return suburb;
	}

	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}

	public int getPostcode() {
		return postcode;
	}

	public void setPostcode(int postcode) {
		this.postcode = postcode;
	}
	
	
}
