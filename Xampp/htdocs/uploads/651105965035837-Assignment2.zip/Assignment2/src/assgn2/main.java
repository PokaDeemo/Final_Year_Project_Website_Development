package assgn2;

import java.util.*;

/**
 * @author Clement Lim
 * @version 1.0
 * Main class to execute the program
 * */

public class main {

	/*public static void displayStudentInfo() {
		System.out.println("Name: Lim Wei Ping Clement Ryan");
		System.out.println("Student ID: 34144638");
		System.out.println("Mode of Enrolment: Full Time");
		System.out.println("Tutor Name: Dr Loo Poh Kok");
		System.out.println("Tutorial Day and Time: Tuesdays, 4:15PM to 6:15PM\n");
	}*/
	
	public static void main(String[] args) {
		
		GUI magazine = new GUI();
		/*Client c = new Client();
		int option = 0;
		ArrayList<Customer> arrayC = new ArrayList<Customer>();
		ArrayList<PayingCustomer> arrayPC = new ArrayList<PayingCustomer>();
		ArrayList<AssociateCustomer> arrayAC = new ArrayList<AssociateCustomer>();
		ArrayList<Supplement> arraySP = new ArrayList<Supplement>();
		
		displayStudentInfo();
		c.populateList(arrayC, arrayPC, arrayAC, arraySP);
		
		Scanner input = new Scanner(System.in);
		
		//Do while loop that exits the loop when user enters 7, which is to quit the program
		do{
			c.menu();
			System.out.println("Enter option: ");
			option = input.nextInt();
			switch(option) {
			case 1: 
				System.out.println("-------------Supplement List-------------");
				c.option1(arraySP);
				break;
			
			case 2:
				System.out.println("-------------Customer List-------------");
				c.option2(arrayC);
				break;
				
			case 3:
				System.out.println("-------------Weekly Email-------------");
				c.option3(arrayC);
				break;
			
			case 4:
				System.out.println("-------------Monthly Email-------------");
				c.option4(arrayPC);
				break;
				
			case 5:
				System.out.println("-------------Add a Customer-------------");
				c.option5(arrayC, arraySP);
				break;
				
			case 6:
				System.out.println("-------------Remove a Customer-------------");
				c.option6(arrayC);
				break;
			default:
				if(option != 7) {
					System.out.println("Enter a valid menu option between 1 to 6, or enter 7 to exit the program.");
				}
				break;
			}
		} while(option != 7);
		
		input.close();
		System.out.println("You quit the program.");*/
	}
}