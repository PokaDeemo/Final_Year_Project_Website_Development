package assgn2;

/**
 * @author Clement Lim
 * @version 1.0
 * Supplement class to store variables and functions related to Supplement
 * */

public class Supplement {
	private String suppName;
	private double suppCost;
	
	public Supplement(String name, double cost) {
	this.suppName = name;
	this.suppCost = cost;
	}
	
	// Getters and setters
	public void setSuppName(String name) {
		this.suppName = name;
	}
	
	public String getSuppName() {
		return suppName;
	}
	
	public void setSuppCost(double cost) {
		this.suppCost = cost;
	}
	
	public double getSuppCost() {
		return suppCost;
	}
	
	//Prints the supplement list
	public void suppList() {
		System.out.println("Supplement Name: " + suppName);
		System.out.println("Supplement Price: $" + suppCost);
	}
	
}
