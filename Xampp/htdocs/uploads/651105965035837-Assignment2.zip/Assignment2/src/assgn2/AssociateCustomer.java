package assgn2;

public class AssociateCustomer extends Customer {

	private String paidBy;
	
	public AssociateCustomer(String name, String email, String paidBy) {
		super(name, email);
		this.paidBy = paidBy;
	}
}
