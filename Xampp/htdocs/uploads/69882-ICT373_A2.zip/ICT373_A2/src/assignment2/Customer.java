package assignment2;

import java.util.*;

/**
 * @author Clement Lim
 * @version 1.0
 * Customer class to store variables and functions related to Customer
 * */

public class Customer {
	protected String custName;
	protected Address address;
	protected String custEmail;
	protected ArrayList<Supplement> suppList;
	protected Supplement supp;
	
	// Default constructor
	public Customer() {
	}

	// Parameterised constructor that takes in name, email, and supplement list as parameters
	public Customer(String name, Address address, String email, ArrayList<Supplement> suppList) {
		this.custName = name;
		this.address = address;
		this.custEmail = email;
		this.suppList = suppList;
	}
	
	// Parameterised constructor that takes in name and email as parameters
	public Customer(String name, String email) {
		this.custName = name;
		this.custEmail = email;
		suppList = new ArrayList<Supplement>();
	}
	
	// Getters and setters
	public void setName(String name) {
		this.custName = name;
	}
	
	public String getName() {
		return custName;
	}
	
	public void setEmail(String email) {
		this.custEmail = email;
	}
	
	public String getEmail() {
		return custEmail;
	}
	
	public ArrayList<Supplement> getSuppList() {
		return suppList;
	}
	
	public void addSupplement(Supplement add) {
		suppList.add(add);
	}
	
	//PRINT FUNCTIONS
	
	//Prints the customer name and email
	public void printCustomerList() {
		System.out.println("Customer Name: " + custName);
		System.out.println("Email: " + custEmail);
	}
	
	//Prints customer name, email, and the supplement that the customers subscribed to
	public void printCustomerListFull() {
		printCustomerList();
		
		for(int i = 0; i < suppList.size(); i++) {
			System.out.println(suppList.get(i).getSuppName());
			System.out.println(suppList.get(i).getSuppCost());
		}
	}
	
	//Print the details of the weekly email
	public void printWeeklyEmail() {
		System.out.println("Customer Email: " + custEmail);
		System.out.println("Hi " + custName + ", here is the list of your weekly magazines for the month!");
		
		//for loop to go through the array list and print out its content
		for(int i = 0; i < suppList.size(); i++) {
			System.out.print("\t" + (i+1) + ".");
			System.out.println(suppList.get(i).getSuppName());
		}
		System.out.println("-----------------------------------------------------------------");
	}
}
