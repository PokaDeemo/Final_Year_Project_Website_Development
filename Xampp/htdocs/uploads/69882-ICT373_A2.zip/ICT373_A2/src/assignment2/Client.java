package assignment2;

import java.util.*;

public class Client {
	
	//Hardcoded data populated into each arraylist
	public void populateList(ArrayList<Customer> arrayC, ArrayList<PayingCustomer> arrayPC, ArrayList<AssociateCustomer> arrayAC, ArrayList<Supplement> arraySP ) {
	
		//Creating 4 associate customers
		AssociateCustomer AC1 = new AssociateCustomer("Amos Soo", "AmosSoo@gmail.com", "Clement Lim");
		AssociateCustomer AC2 = new AssociateCustomer("Melvin Teo", "MelvinTeo@gmail.com", "Marcus Yap");
		AssociateCustomer AC3 = new AssociateCustomer("Jace Ng", "JaceNg@gmail.com", "Leslie Sim");
		AssociateCustomer AC4 = new AssociateCustomer("Dandy Chen", "DandyChen@gmail.com", "Clement Lim");
		
		//Combining associate customers to another arraylist so that they can
		//be bundled together with a paying customer
		ArrayList<AssociateCustomer> C1 = new ArrayList<AssociateCustomer>();
		C1.add(AC1);
		C1.add(AC4);
		ArrayList<AssociateCustomer> C2 = new ArrayList<AssociateCustomer>();
		C2.add(AC2);
		ArrayList<AssociateCustomer> C3 = new ArrayList<AssociateCustomer>();
		C3.add(AC3);
		
		//Creating 3 paying customers, and adding the earlier arraylist to each paying customer
		PayingCustomer PC1 = new PayingCustomer("Clement Lim", "ClementLim@gmail.com", "Credit Card", "81230001", C1);
		PayingCustomer PC2 = new PayingCustomer("Marcus Yap", "MarcusYap@gmail.com", "Debit Card", "74560002", C2);
		PayingCustomer PC3 = new PayingCustomer("Leslie Sim", "LeslieSim@gmail.com", "Credit Card", "81110003", C3);

		//Creating 3 supplements
		Supplement SP1 = new Supplement("Car Drifts", 9.90);
		Supplement SP2 = new Supplement("Daily Dose", 5.90);
		Supplement SP3 = new Supplement("Fresh Florals", 5.90);
		
		// Populating Supplement List
		arraySP.add(SP1);
		arraySP.add(SP2);
		arraySP.add(SP3);
		
		// Populating PayingCustomer
		arrayPC.add(PC1);
		arrayPC.add(PC2);
		arrayPC.add(PC3);
		
		// Populating Customer
		arrayC.add(AC1);
		arrayC.add(AC2);
		arrayC.add(AC3);
		arrayC.add(AC4);
		arrayC.add(PC1);
		arrayC.add(PC2);
		arrayC.add(PC3);
		
		// Populating Supplement list to Customer
		AC1.addSupplement(SP1);
		AC1.addSupplement(SP2);
		AC2.addSupplement(SP3);
		AC2.addSupplement(SP2);
		AC3.addSupplement(SP3);
		AC4.addSupplement(SP1);
		AC4.addSupplement(SP2);
		AC4.addSupplement(SP3);
		PC1.addSupplement(SP3);
		PC1.addSupplement(SP1);
		PC2.addSupplement(SP2);
		PC3.addSupplement(SP1);
		
	}
	
	//Print menu
	public void menu() {
		System.out.println("\n--------------Menu--------------");
		System.out.println("1. Display Supplement List");
		System.out.println("2. Display Customer List");
		System.out.println("3. Display four weeks magazines cost for all customer");
		System.out.println("4. Display end of month bill for paying customer");
		System.out.println("5. Add a new customer to magazine service");
		System.out.println("6. Remove an existing customer from magazine service");
		System.out.println("7. Exit");
	}

	//Display Supplement List
	public void option1(ArrayList<Supplement> arraySP) {		
		for(int i = 0; i < arraySP.size(); i++) {
			System.out.print(i+1 + ". ");
			arraySP.get(i).suppList();
			System.out.println();
		}
	}
	
	//Display Customer List
	public void option2(ArrayList<Customer> arrayC) {
		for(int i = 0; i < arrayC.size(); i++) {
			System.out.print(i+1 + ". ");
			arrayC.get(i).printCustomerList();
			System.out.println();
		}
	}
	
	//Display Weekly Email with serial number
	public void option3(ArrayList<Customer> arrayC) {
		for(int i = 0; i < arrayC.size(); i++) {
			System.out.print(i+1 + ". ");
			arrayC.get(i).printWeeklyEmail();
			System.out.println();
		}
	}
	
	//Display Monthly Email with serial number
	public void option4(ArrayList<PayingCustomer> arrayPC) {
		for(int i = 0; i < arrayPC.size(); i++) {
			System.out.println(i+1 + ". ");
			arrayPC.get(i).printMonthlyEmail();
			System.out.println();
		}
	}
	
	//Adding customer to database
	public void option5(ArrayList<Customer> arrayC, ArrayList<Supplement> arraySP) {
		Customer newCust = new Customer();
		Scanner input = new Scanner(System.in);
		boolean flag = false; // for validation
		
		//Adding Name
		System.out.println("Add Customer Name: ");
		String name = input.nextLine();
		
		//validation for loop that checks the user input against the names in arraylist
		//if there is a match, flag becomes true
		for(int i = 0; i < arrayC.size(); i++) {
			if(arrayC.get(i).getName().equalsIgnoreCase(name)) {
				flag = true;
			}
		}
		
		//loops while the flag is true or if the input is empty
		while(flag == true || name.isEmpty()) {
			System.out.println("Name is either empty or already exist in database.");
			System.out.println("Add Customer Name: ");
			name = input.nextLine();
			for(int i = 0; i < arrayC.size(); i++) {
				if(!(arrayC.get(i).getName().equalsIgnoreCase(name))) {
					flag = false;
				}
			}
		}
		
		
		//Adding Email
		System.out.println("Add Customer Email: ");
		String email = input.nextLine();

		for(int i = 0; i < arrayC.size(); i++) {
			if(arrayC.get(i).getEmail().equalsIgnoreCase(email)) {
				flag = true;
			}
		}
		
		while(flag == true || email.isEmpty()) {
			System.out.println("Email is either empty or already exist in database.");
			System.out.println("Add Customer Email: ");
			email = input.nextLine();
			for(int i = 0; i < arrayC.size(); i++) {
				if(!(arrayC.get(i).getEmail().equalsIgnoreCase(email))) {
					flag = false;
				}
			}
		} 
		
		//Adding Supplement
		//Could not figure out how to add a supplement into customer... 
		/*for(int i = 0; i < arraySP.size(); i++) {
			System.out.print(i+1 + ". ");
			arraySP.get(i).suppList();
			System.out.println("");
		}
		System.out.println("Select Supplement that the customer will subscribe to: ");
		int supp = input.nextInt();*/
				
			newCust.setName(name);
			newCust.setEmail(email);
			arrayC.add(newCust);
			/*if(supp == 1) {
				newCust.addSupplement(arraySP.add(null)
			}*/
			
			System.out.println("\nNew customer has been added.\n");
			option2(arrayC); //display the updated customer list
	}
	
	//Removing customer from database
	public void option6(ArrayList<Customer> arrayC) {
		Scanner input = new Scanner(System.in);
		boolean flag = false; // for validation
		
		System.out.println("Remove Customer Name: ");
		String name = input.nextLine();
		
		//validation for loop that checks if the input matches any names in the arraylist
		//flag is set to true if there are any matches.
		for(int i = 0; i < arrayC.size(); i++) {
			if(arrayC.get(i).getName().equalsIgnoreCase(name)) {
				arrayC.remove(i);
				flag = true; 
			}
		}
		
		//if flag is false it means there are no such customer in the system, 
		//and if true, the customer will be removed from the system
		if(flag == false) {
			System.out.println("\nCustomer not found in the system.\n");
		} else {
			System.out.println("\nCustomer has been removed from the system.\n");
		}
		option2(arrayC); //prints current customer list for confirmation
	}
}
