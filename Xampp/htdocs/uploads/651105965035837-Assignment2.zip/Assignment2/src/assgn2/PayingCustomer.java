package assgn2;

/**
 * @author Clement Lim
 * @version 1.0
 * PayingCustomer class to store variables and functions related to paying customers
 * */

import java.util.*;

public class PayingCustomer extends Customer{
	private String payMethod;
	private String bankNo;
	private ArrayList<AssociateCustomer> acList;
	 
	/*Parameterised constructor that takes name, email, payMethod, bankNo, 
	* and associate customer list as parameters
	*/
	public PayingCustomer(String name, String email, String payMethod, String bankNo,
			ArrayList<AssociateCustomer> acList) {
		super(name, email);
		this.payMethod = payMethod;
		this.bankNo = bankNo;
		this.acList = acList;
	}
	
	//Getters and setters
	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}
	
	public String getPayMethod() {
		return payMethod;
	}
	
	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}
	
	public String getBankNo() {
		return bankNo;
	}
	
	//PRINT FUNCTIONS
	
	//Prints the customer name and email
	public void printPC() {
		System.out.println("Customer Name: " + custName);
		System.out.println("Email: " + custEmail);
	}
	
	//Prints the details of the monthly email
	public void printMonthlyEmail() {
		double total = 0.0;
		System.out.println("Customer Email: " + custEmail);
		System.out.println("Hi " + custName + ", here is bill that will be charged to your card at the end of the month.");
		String format = "%-30s%s%n";
		System.out.println();
		
		System.out.println("Customers associated with you: ");
		for(int i = 0; i < acList.size(); i++) {
			System.out.println(acList.get(i).custName);
		}
		
		/* The supplement list is formatted using String format and printf
		 * the total adds both associate and paying customers' supplement subscription
		 */
		System.out.println("\n----------------Supplement List----------------");
		System.out.printf(format, "\tSupplement Name", "Supplement Cost");
		for(int i = 0; i < suppList.size(); i++) {
			System.out.printf(format, "\t" + suppList.get(i).getSuppName(), "$" + suppList.get(i).getSuppCost());
			System.out.printf(format, "\t" + acList.get(i).suppList.get(i).getSuppName(), "$" + acList.get(i).suppList.get(i).getSuppCost());
			total += (suppList.get(i).getSuppCost() + acList.get(i).suppList.get(i).getSuppCost());
		}
		System.out.println("Total cost: $" + total);
		
	}
}
