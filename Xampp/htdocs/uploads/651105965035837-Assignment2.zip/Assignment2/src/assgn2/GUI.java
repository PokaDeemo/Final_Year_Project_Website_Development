package assgn2;

import java.awt.*;
import javax.swing.*;

class SuppPanel extends JPanel {
	public SuppPanel() {
		JLabel suppName = new JLabel("Name");
		add(suppName);
		JTextField suppNameTxt = new JTextField();
		suppNameTxt.setPreferredSize(new Dimension(500, 30));
		add(suppNameTxt);
		
		add(new JLabel("Cost"));
		JTextField suppCostTxt = new JTextField();
		suppCostTxt.setPreferredSize(new Dimension(500, 30));
		add(suppCostTxt);
		
		add(new JLabel("Date"));
		JTextField suppDateTxt = new JTextField();
		suppDateTxt.setPreferredSize(new Dimension(500, 30));
		add(suppDateTxt);
		
		add(new JLabel("Subscribed Customers"));
		DefaultListModel suppSubModel = new DefaultListModel();
		JList suppSubList = new JList(suppSubModel);
		JScrollPane suppSubScroll = new JScrollPane(suppSubList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
		suppSubList.setPreferredSize(new Dimension(500, 200));
		add(suppSubList);
	}
}


class CustPanel extends JPanel {
	public CustPanel() {
		JLabel custName = new JLabel("Name");
		add(custName);
		JTextField custNameTxt = new JTextField();
		custNameTxt.setPreferredSize(new Dimension(500, 30));
		add(custNameTxt);
		
		JLabel custAddr = new JLabel("Address");
		add(custAddr);
		JTextField custAddrTxt = new JTextField();
		custAddrTxt.setPreferredSize(new Dimension(500, 30));
		add(custAddrTxt);
		
		JLabel custSub= new JLabel("List of Subscriptions");
		add(custSub);
		DefaultListModel custSubModel = new DefaultListModel();
		JList custSubList = new JList(custSubModel);
		JScrollPane custSubScroll = new JScrollPane(custSubList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
		custSubList.setPreferredSize(new Dimension(500, 200));
		add(custSubList);
		
		add(new JLabel("Status"));
		JTextField custStsTxt = new JTextField();
		custStsTxt.setPreferredSize(new Dimension(500, 30));
		add(custStsTxt);
		
		add(new JLabel("List of Associate Customers"));
		DefaultListModel custAscModel = new DefaultListModel();
		JList custAscList = new JList(custAscModel);
		JScrollPane suppAscScroll = new JScrollPane(custAscList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
		custAscList.setPreferredSize(new Dimension(500, 200));
		add(custAscList);
	}
}
class GUI {
	public static void main(String args[]) {
		
		Font fontOne = new Font("Roboto", Font.BOLD, 25);
		Font fontTwo = new Font("Roboto", Font.PLAIN, 15);
		
		//FRAME
		JFrame frame = new JFrame("ICT373 Assignment 2 - Clement Lim");
		Container content = frame.getContentPane();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800);
		
		//NORTH PANEL
		JPanel northPanel = new JPanel(new BorderLayout()); //Border layout here is split the north panel up again
		JLabel northTitle = new JLabel("Magazine Service");
		northTitle.setFont(fontOne);
		northTitle.setHorizontalAlignment(JLabel.CENTER);
		
		JPanel northBtn = new JPanel();
		JButton view = new JButton("View");
		JButton create = new JButton("Create");
		JButton edit = new JButton("Edit");
		northBtn.add(view);
		northBtn.add(create);
		northBtn.add(edit);
		northPanel.add(northTitle,BorderLayout.NORTH); // title above
		northPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		northPanel.add(northBtn,BorderLayout.SOUTH); //buttons below
		//end of north panel
		
        //SOUTH PANEL
        JPanel southPanel = new JPanel();
        JButton exit = new JButton("Exit");
        southPanel.add(exit); 
        //end of south panel
        
        //CENTER PANEL
        JPanel centerPanel = new JPanel(new BorderLayout());
        JLabel centerTitle = new JLabel("Information Panel");
        centerPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        centerTitle.setFont(fontTwo);
        
        CardLayout cardLayout = new CardLayout();
        JPanel infoPanel = new JPanel(cardLayout);
        SuppPanel infosuppPanel = new SuppPanel();
        CustPanel infocustPanel = new CustPanel();
        infoPanel.add(infosuppPanel, "supp");
        infoPanel.add(infocustPanel, "cust");
        centerPanel.add(centerTitle,BorderLayout.NORTH);
        centerPanel.add(infoPanel);
        //cardLayout.show(infoPanel, "cust");
        cardLayout.show(infoPanel, "supp");
        
        
        
        //WEST PANEL
        //Supplement list
        JPanel suppPanel = new JPanel(new BorderLayout());
        JLabel suppTitle = new JLabel("List of Supplements");
        suppTitle.setFont(fontTwo);
        DefaultListModel suppListModel = new DefaultListModel();
        JList suppList = new JList(suppListModel);
        JScrollPane suppListScroll = new JScrollPane(suppList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        suppPanel.add(suppTitle,BorderLayout.NORTH);
        suppPanel.add(suppListScroll);
        
        //Customer list
        JPanel custPanel = new JPanel(new BorderLayout());
        JLabel custTitle = new JLabel("List of Customers");
        custTitle.setFont(fontTwo);
        DefaultListModel custListModel = new DefaultListModel();
        JList custList = new JList(custListModel);
        JScrollPane custListScroll = new JScrollPane(custList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        custPanel.add(custTitle,BorderLayout.NORTH);
        custPanel.add(custListScroll);
        
        //West panel
        JSplitPane westPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, suppPanel, custPanel);
        westPanel.setOneTouchExpandable(true);
        westPanel.setDividerLocation(300);


        //Adding Components to the frame.
        content.add(northPanel,BorderLayout.NORTH);
        content.add(southPanel,BorderLayout.SOUTH);
        content.add(centerPanel,BorderLayout.CENTER);
        content.add(westPanel,BorderLayout.WEST);
        
        frame.setVisible(true);
	}


}
