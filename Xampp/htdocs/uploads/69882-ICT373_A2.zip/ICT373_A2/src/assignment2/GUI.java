package assignment2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class GUI extends JFrame {
	
	Font fontOne = new Font("Roboto", Font.BOLD, 25);
	Font fontTwo = new Font("Roboto", Font.PLAIN, 15);
	private static final long serialVersionUID = 1L;
	boolean viewMode = true;;
	
	
	//NORTH PANEL
	JPanel northPanel = new JPanel(new BorderLayout()); //Border layout here is split the north panel up again
	JLabel northTitle = new JLabel("Magazine Service");
	JPanel northBtn = new JPanel();
	JButton view = new JButton("View");
	JButton create = new JButton("Create");
	JButton edit = new JButton("Edit");
	
	//SOUTH PANEL
    JPanel southPanel = new JPanel();
    JButton exit = new JButton("Exit");
    
    //CENTER PANEL
    JPanel centerPanel = new JPanel(new BorderLayout());
    JLabel centerTitle = new JLabel("Information Panel");
    CardLayout cardLayout = new CardLayout();
    JPanel infoPanel = new JPanel(cardLayout);
    SuppPanel infosuppPanel = new SuppPanel();
    CustPanel infocustPanel = new CustPanel();
    
    //WEST PANEL
    //Supplement
    JPanel suppPanel = new JPanel(new BorderLayout());
    JLabel suppTitle = new JLabel("List of Supplements");
    DefaultListModel suppListModel = new DefaultListModel();
    JList suppList = new JList(suppListModel);
    JScrollPane suppListScroll = new JScrollPane(suppList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    //Customer
    JPanel custPanel = new JPanel(new BorderLayout());
    JLabel custTitle = new JLabel("List of Customers");
    DefaultListModel custListModel = new DefaultListModel();
    JList custList = new JList(custListModel);
    JScrollPane custListScroll = new JScrollPane(custList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    JSplitPane westPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, suppPanel, custPanel);
    
    
	GUI() {
	//FRAME
	JFrame frame = new JFrame("ICT373 Assignment 2 - Clement Lim");
	Container content = frame.getContentPane();
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setSize(800, 800);
	
	//NORTH PANEL

	view.addActionListener((ActionEvent e) -> { modeView();});
	edit.addActionListener((ActionEvent e) -> { modeView();});
	view.setEnabled(false);
	
	northTitle.setFont(fontOne);
	northTitle.setHorizontalAlignment(JLabel.CENTER);
	northBtn.add(view);
	northBtn.add(create);
	northBtn.add(edit);
	northPanel.add(northTitle,BorderLayout.NORTH); // title above
	northPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
	northPanel.add(northBtn,BorderLayout.SOUTH); //buttons below
	//end of north panel
	
    //SOUTH PANEL
    southPanel.add(exit); 
    //end of south panel
    
    //CENTER PANEL

    centerPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
    centerTitle.setFont(fontTwo);
    infoPanel.add(infosuppPanel, "supp");
    infoPanel.add(infocustPanel, "cust");
    centerPanel.add(centerTitle,BorderLayout.NORTH);
    centerPanel.add(infoPanel);
    cardLayout.show(infoPanel, "cust");
    //cardLayout.show(infoPanel, "supp");
    
    //WEST PANEL
    //Supplement list

    suppTitle.setFont(fontTwo);
    suppPanel.add(suppTitle,BorderLayout.NORTH);
    suppPanel.add(suppListScroll);
    
    //Customer list

    custTitle.setFont(fontTwo);
    custPanel.add(custTitle,BorderLayout.NORTH);
    custPanel.add(custListScroll);
    
    //West panel
    westPanel.setOneTouchExpandable(true);
    westPanel.setDividerLocation(300);

    //Adding Components to the frame.
    content.add(northPanel,BorderLayout.NORTH);
    content.add(southPanel,BorderLayout.SOUTH);
    content.add(centerPanel,BorderLayout.CENTER);
    content.add(westPanel,BorderLayout.WEST);
    
    frame.setVisible(true);
}
	
	//FUNCTIONS
	public void modeSwitch(boolean flag) {
		infosuppPanel.suppNameTxt.setEditable(flag);
		infosuppPanel.suppCostTxt.setEditable(flag);
		infosuppPanel.suppDateTxt.setEditable(flag);
		infocustPanel.custNameTxt.setEditable(flag);
		infocustPanel.custAddrTxt.setEditable(flag);
		infocustPanel.custStsTxt.setEditable(flag);
	}
	
	public void modeView() {
		if(viewMode) {
			viewMode = false;
			view.setEnabled(true);
			edit.setEnabled(false);
			modeSwitch(!viewMode);
		} else {
			viewMode = true;
			view.setEnabled(false);
			edit.setEnabled(true);
			modeSwitch(!viewMode);
		}
	}
}

class SuppPanel extends JPanel {
	JLabel suppName = new JLabel("Name");
	JTextField suppNameTxt = new JTextField();
	JLabel suppCost = new JLabel("Cost");
	JTextField suppCostTxt = new JTextField();
	JLabel suppDate = new JLabel("Date");
	JTextField suppDateTxt = new JTextField();
	JLabel suppSub = new JLabel("Subscribed Customers");
	DefaultListModel suppSubModel = new DefaultListModel();
	JList suppSubList = new JList(suppSubModel);
	JScrollPane suppSubScroll = new JScrollPane(suppSubList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
	
	public SuppPanel() {
		add(suppName);
		add(suppNameTxt);
		add(suppCost);
		add(suppCostTxt);
		add(suppDate);
		add(suppDateTxt);
		add(suppSub);
		add(suppSubList);
		suppNameTxt.setPreferredSize(new Dimension(500, 30));
		suppCostTxt.setPreferredSize(new Dimension(500, 30));
		suppDateTxt.setPreferredSize(new Dimension(500, 30));
		suppSubList.setPreferredSize(new Dimension(500, 200));
	}
}

class CustPanel extends JPanel {
	JLabel custName = new JLabel("Name");
	JTextField custNameTxt = new JTextField();
	JLabel custAddr = new JLabel("Address");
	JTextField custAddrTxt = new JTextField();
	JLabel custSub = new JLabel("List of Subscriptions");
	DefaultListModel custSubModel = new DefaultListModel();
	JList custSubList = new JList(custSubModel);
	JScrollPane custSubScroll = new JScrollPane(custSubList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
	JLabel custSts = new JLabel("Status");
	JTextField custStsTxt = new JTextField();
	JLabel custAsc = new JLabel("List of Associate Customers");
	DefaultListModel custAscModel = new DefaultListModel();
	JList custAscList = new JList(custAscModel);
	JScrollPane suppAscScroll = new JScrollPane(custAscList,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
	
	public CustPanel() {
		add(custName);
		custNameTxt.setPreferredSize(new Dimension(500, 30));
		add(custNameTxt);
		add(custAddr);
		custAddrTxt.setPreferredSize(new Dimension(500, 30));
		add(custAddrTxt);
		add(custSub);
		custSubList.setPreferredSize(new Dimension(500, 200));
		add(custSubList);
		add(custSts);
		custStsTxt.setPreferredSize(new Dimension(500, 30));
		add(custStsTxt);
		add(custAsc);
		custAscList.setPreferredSize(new Dimension(500, 200));
		add(custAscList);
	}
}

